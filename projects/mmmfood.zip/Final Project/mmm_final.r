# Youbeen Shim

# Working Directory
setwd('~/Desktop/RestaurantData')

# Libraries
library(tidyverse)
library(cluster)

# Data
u_cuisine <- read_csv("usercuisine.csv") %>% na.omit()
r_cuisine <- read_csv("chefmozcuisine.csv") %>% na.omit()
rating <- read_csv("rating_final.csv") %>% na.omit()
u_features <- read_csv("userprofile.csv") %>% na.omit()

# Data Cleaning & Organizing
# orgRating - User, Place, Rating, Matching
orgRating <- rating %>%
  inner_join(r_cuisine, by="placeID") %>%
  inner_join(u_cuisine, by="userID") %>%
  mutate(matching=ifelse(Rcuisine.x==Rcuisine.y, 1, 0)) %>%
  group_by(userID, placeID) %>%
  arrange(desc(matching)) %>%
  filter(row_number()==1L) %>%
  select(userID, placeID, rating, matching)
orgRating

# withFeature - orgRating plus user description
withFeature <- orgRating %>%
  inner_join(u_features, by='userID') %>%
  mutate(smoker=ifelse(smoker=='true', 1, 0)) %>%
  select(-latitude, -longitude)
withFeature

# whereYoubeen - Places the user has been to & what they served
whereYoubeen <- rating %>%
  inner_join(r_cuisine, by='placeID') %>%
  select(userID, placeID, Rcuisine, rating)
whereYoubeen

# freqVisit - User, type of food they go for, and how frequently (+ avg rating for that type of food)
freqVisit <- whereYoubeen %>%
  group_by(userID, Rcuisine) %>%
  mutate(count=n(), avg=mean(rating)) %>%
  select(userID, Rcuisine, count, avg) %>%
  distinct(genre_rating_group, .keep_all = TRUE)

# horizontal - freqVisit with types of food as columns
horizontal <- freqVisit %>% 
  select(userID, Rcuisine, count) %>%
  spread(Rcuisine, count, fill=0) %>% na.omit()

# Export Data
write.csv(orgRating, file = "orgRating.csv")
write.csv(withFeature, file = "withFeature.csv")

# Type of Food offered by Restaurants
unique(r_cuisine$Rcuisine) # Approx. 60 Types of Food offered

# Testing Clustering - pick the best k: minimize withinss, maximize betweenss
output <- matrix(ncol=3, nrow=30)
for (i in 1:20) {
  output[i,1] <- i
  km <- kmeans(horizontal[c(2:4,6:19,21:24)], i, nstart=20)
  output[i,2] <- mean(km$withinss)
  output[i,3] <- mean(km$betweenss)
}
colnames(output) <- c('cluster', 'within', 'between')
output <- data.frame(output)

ggplot(output, aes(x=cluster, y=within)) + geom_point() 
ggplot(output, aes(x=cluster, y=between)) + geom_point()

km <- kmeans(horizontal[c(2:4,6:19,21:24)], 6, nstart=20)
k_cluster <- km$centers

# Testing Clustering 2
horizontal2 <- freqVisit %>%
  mutate(present=ifelse(count>0, 1, 0)) %>%
  select(userID, Rcuisine, present) %>%
  spread(Rcuisine, present, fill=0) %>% na.omit()

output2 <- matrix(ncol=3, nrow=30)
for (i in 1:20) {
  output2[i,1] <- i
  km <- kmeans(horizontal2[2:24], i, nstart=20)
  output2[i,2] <- mean(km$withinss)
  output2[i,3] <- mean(km$betweenss)
}
colnames(output2) <- c('cluster', 'within', 'between')
output2 <- data.frame(output2)

ggplot(output2, aes(x=cluster, y=within)) + geom_point() + theme_classic()
ggplot(output2, aes(x=cluster, y=between)) + geom_point() + theme_classic()

km <- kmeans(horizontal2[2:24], 6, nstart=20)
k_cluster <- km$centers
