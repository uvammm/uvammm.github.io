#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 18:00:26 2019

@author: barrychin
"""


import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
# The important variables: budget, activity, marital_status, smoker, drink level, dress_preference  

#Reading the files 
df_features = pd.read_csv('RestaurantData/withFeature.csv')
df_features = df_features[['userID', 'rating', 'matching', "budget", 'activity', 'marital_status', 'smoker', 'drink', "dress_preference"]]

df_uCuisine = pd.read_csv('RestaurantData/usercuisine.csv')
df_uCuisine = df_uCuisine[['userID', 'Rcuisine']]

df_geoplaces = pd.read_csv('RestaurantData/geoplaces2.csv', encoding='ISO-8859-1')
df_geoplaces = df_geoplaces[['placeID', 'name']]

#Merging data
df_features = pd.merge(df_features, df_uCuisine, on=['userID'])

#Creating Dummy Variables
df_features = pd.get_dummies(df_features, columns=['budget'], prefix = ['budget'])
df_features = pd.get_dummies(df_features, columns=['activity'], prefix = ['activity'])
df_features = pd.get_dummies(df_features, columns=['marital_status'], prefix = ['marital_status'])
df_features = pd.get_dummies(df_features, columns=['dress_preference'], prefix = ['dress_preference'])

#OLS Regression
x_feature = df_features[['matching', "budget_low", 'budget_medium', 'budget_high', 'activity_student', 'activity_professional', 'activity_unemployed', 'activity_working-class', 'marital_status_single', 'marital_status_married', 'smoker', 'drink', "dress_preference_informal", "dress_preference_no preference", "dress_preference_formal"]]
y_feature = df_features[['rating']]

model = sm.OLS(y_feature, x_feature).fit()  # fit the model
print(model.summary()) 

#2 Sample t-test on ratings based on matching
df_ratings = pd.read_csv('RestaurantData/withFeature.csv')
df_ratings = df_ratings['rating']

print(stats.ttest_ind(df_ratings[0:219], df_ratings[220:]))

